Dépose ici les images et fichiers copiés tels quels à la racine du site.
