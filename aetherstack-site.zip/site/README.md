# Site AetherStack

Site personnel statique. Tout le contenu vit dans **un seul fichier** : `content.json`.
Tu le modifies, GitHub reconstruit et republie le site tout seul.

---

## 1. Mise en route (une seule fois)

### a. Envoyer le code sur GitHub

Si le dépôt est déjà créé et vide :

```bash
git init
git add .
git commit -m "Première version du site"
git branch -M main
git remote add origin https://github.com/TON-PSEUDO/TON-DEPOT.git
git push -u origin main
```

*(Ou : sur github.com → « Add file » → « Upload files » → glisse tous les fichiers.)*

### b. Activer GitHub Pages

Dans le dépôt : **Settings → Pages → Build and deployment → Source : `GitHub Actions`**.

C'est tout. Au prochain push, le site se construit et se publie sur
`https://TON-PSEUDO.github.io/TON-DEPOT/`

L'onglet **Actions** montre l'avancement (environ 1 minute).

---

## 2. Modifier le contenu

### Option A — le back-office (recommandé)

Va sur `https://TON-PSEUDO.github.io/TON-DEPOT/admin/`

Il te faut un jeton GitHub, à créer une seule fois :

1. [github.com/settings/personal-access-tokens/new](https://github.com/settings/personal-access-tokens/new)
2. **Repository access** → *Only select repositories* → choisis ce dépôt
3. **Permissions** → *Repository permissions* → **Contents : Read and write**
4. Generate token, copie-le

Colle-le dans le back-office. Il reste **dans ton navigateur uniquement** (localStorage),
il n'est jamais envoyé ailleurs qu'à l'API de GitHub.

Ensuite : tu édites les champs, tu cliques **Publier**, le site se met à jour tout seul.

### Option B — directement sur GitHub

Ouvre `content.json` sur github.com, clique le crayon ✏️, modifie, « Commit changes ».
Même résultat.

> Ne change que les textes **entre guillemets**. Les noms de champs à gauche des `:`
> doivent rester tels quels, sinon le site ne se construira pas.

---

## 3. Travailler en local

```bash
node build.mjs     # génère le site dans /dist
node serve.mjs     # http://localhost:4173
```

Aucune dépendance à installer. Node 18+ suffit.

---

## 4. Structure

```
content.json              ← TOUT le contenu du site (le seul fichier à modifier)
build.mjs                 ← génère /dist à partir de content.json
serve.mjs                 ← serveur de prévisualisation local
src/
  layout.mjs              ← gabarit HTML commun (head, nav, pied de page)
  pages.mjs               ← structure des 4 pages
  styles/main.css         ← toute la mise en forme
  scripts/field.js        ← animation 3D d'arrière-plan (Three.js)
  scripts/site.js         ← menu mobile, animations au scroll, formulaire
admin/index.html          ← back-office d'édition
public/                   ← fichiers copiés tels quels (images, CNAME…)
.github/workflows/        ← construction + publication automatiques
```

---

## 5. Personnalisation courante

| Ce que tu veux changer | Où |
|---|---|
| Textes, projets, services, email | `content.json` |
| Couleurs | `src/styles/main.css`, bloc `:root` en haut |
| Polices | `src/layout.mjs`, constante `FONTS` |
| Animation 3D de fond | `src/scripts/field.js` |
| Ajouter/retirer une page | `src/pages.mjs` + tableau `ROUTES` dans `build.mjs` + `nav` dans `content.json` |

### Couleurs actuelles

| Rôle | Valeur |
|---|---|
| Fond | `#08090C` |
| Texte | `#E8E9ED` |
| Accent (froid) | `#9FB4FF` |
| Signal (chaud, boutons) | `#FFB86B` |

### Mettre un nom de domaine perso

1. Crée un fichier `public/CNAME` contenant uniquement ton domaine, ex. `aetherstack.dev`
2. Chez ton registrar, pointe le domaine vers GitHub Pages
3. Settings → Pages → Custom domain

Le workflow détecte le `CNAME` et ajuste automatiquement les chemins.

### Ajouter des images

Dépose-les dans `public/` puis référence-les dans `content.json` par `/nom-image.jpg`.

---

## 6. Le formulaire de contact

Il ouvre le client mail du visiteur (`mailto:`) — **aucun service tiers, aucune donnée stockée**.

Pour recevoir les messages directement dans une boîte sans passer par le client mail du
visiteur, il faut un service externe (Formspree, Web3Forms…) : remplace le `<form>` généré
dans `src/pages.mjs` par leur endpoint.

---

## 7. Si ça ne marche pas

| Symptôme | Cause probable |
|---|---|
| Action rouge dans l'onglet Actions | `content.json` mal formé — une virgule ou un guillemet en trop |
| Page blanche, styles absents | GitHub Pages pas encore en mode « GitHub Actions » (étape 1b) |
| Le back-office refuse le jeton | Permission `Contents: Read and write` manquante, ou mauvais dépôt sélectionné |
| Modification invisible | Attends ~1 min, puis recharge avec Ctrl+Shift+R |

Pour vérifier que `content.json` est valide avant de pousser : `node -e "JSON.parse(require('fs').readFileSync('content.json'))"`
