#!/usr/bin/env node
/* ============================================================
   Génère le site statique dans /dist à partir de content.json.
   Usage : node build.mjs
   ============================================================ */
import { readFile, writeFile, mkdir, rm, cp } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import { page } from './src/layout.mjs';
import * as P from './src/pages.mjs';

const root = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(root, 'dist');

/* Chemin de base : variable d'env (posée par GitHub Actions),
   sinon celui de content.json, sinon la racine. */
const content = JSON.parse(await readFile(path.join(root, 'content.json'), 'utf8'));
const base = (process.env.BASE_PATH ?? content.site.baseUrl ?? '').replace(/\/$/, '');

const ROUTES = [
  { path: '/',          out: 'index.html',            title: 'Accueil',  render: P.home },
  { path: '/projets/',  out: 'projets/index.html',    title: content.projects.title, render: P.projects },
  { path: '/approche/', out: 'approche/index.html',   title: content.about.title,    render: P.about },
  { path: '/contact/',  out: 'contact/index.html',    title: content.contact.title,  render: P.contact },
  { path: '/404',       out: '404.html',              title: 'Page introuvable',     render: P.notFound, noindex: true },
];

async function build() {
  await rm(dist, { recursive: true, force: true });
  await mkdir(dist, { recursive: true });

  // Pages
  for (const r of ROUTES) {
    const body = r.render(content, base);
    const html = page({
      content,
      base,
      title: r.title,
      description: r.path === '/' ? content.site.description : undefined,
      path: base + r.path,
      body,
    });
    const dest = path.join(dist, r.out);
    await mkdir(path.dirname(dest), { recursive: true });
    await writeFile(dest, html, 'utf8');
    console.log('  ✓', r.out);
  }

  // Assets
  await mkdir(path.join(dist, 'assets'), { recursive: true });
  await cp(path.join(root, 'src/styles/main.css'), path.join(dist, 'assets/main.css'));
  await cp(path.join(root, 'src/scripts/field.js'), path.join(dist, 'assets/field.js'));
  await cp(path.join(root, 'src/scripts/site.js'), path.join(dist, 'assets/site.js'));
  console.log('  ✓ assets/');

  // Back-office
  if (existsSync(path.join(root, 'admin'))) {
    await cp(path.join(root, 'admin'), path.join(dist, 'admin'), { recursive: true });
    console.log('  ✓ admin/');
  }

  // Fichiers publics éventuels (images, CNAME, ...)
  if (existsSync(path.join(root, 'public'))) {
    await cp(path.join(root, 'public'), dist, { recursive: true });
  }

  // content.json est copié pour que /admin puisse le relire
  await cp(path.join(root, 'content.json'), path.join(dist, 'content.json'));

  // Empêche GitHub Pages de faire tourner Jekyll (il ignorerait les dossiers _*)
  await writeFile(path.join(dist, '.nojekyll'), '', 'utf8');

  // robots.txt + sitemap
  const origin = (content.site.canonicalOrigin || '').replace(/\/$/, '');
  await writeFile(path.join(dist, 'robots.txt'),
    `User-agent: *\nAllow: /\n${origin ? `Sitemap: ${origin}${base}/sitemap.xml\n` : ''}`, 'utf8');

  if (origin) {
    const urls = ROUTES.filter((r) => !r.noindex)
      .map((r) => `  <url><loc>${origin}${base}${r.path}</loc></url>`).join('\n');
    await writeFile(path.join(dist, 'sitemap.xml'),
      `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`, 'utf8');
  }

  console.log(`\nSite généré dans /dist  (base: "${base || '/'}")`);
}

build().catch((e) => { console.error(e); process.exit(1); });
