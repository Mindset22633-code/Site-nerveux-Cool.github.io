/* Gabarit commun : <head>, navigation, pied de page. */

export const esc = (s = '') =>
  String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');

/** Résout un lien interne en tenant compte du sous-dossier GitHub Pages. */
export const link = (base, href = '') => {
  if (/^(https?:|mailto:|tel:|#)/.test(href)) return href;
  const clean = ('/' + href).replace(/\/+/g, '/');
  return (base + clean).replace(/\/+/g, '/') || '/';
};

const FONTS =
  'https://fonts.googleapis.com/css2' +
  '?family=Instrument+Serif:ital@0;1' +
  '&family=Instrument+Sans:wght@400;500;600' +
  '&family=JetBrains+Mono:wght@300;400;500' +
  '&display=swap';

function nav(content, base, current) {
  return content.nav
    .map((item) => {
      const href = link(base, item.href);
      const isCurrent =
        href.replace(/\/$/, '') === current.replace(/\/$/, '');
      return `<a href="${esc(href)}"${isCurrent ? ' aria-current="page"' : ''}>${esc(item.label)}</a>`;
    })
    .join('');
}

function footer(content, base) {
  const s = content.site;
  const links = (s.socials || [])
    .map((x) => `<a href="${esc(x.href)}" rel="me noopener">${esc(x.label)}</a>`)
    .join('');
  return `
  <footer class="foot">
    <div class="wrap foot-inner">
      <div>&copy; <span data-year>${new Date().getFullYear()}</span> ${esc(s.name)} · ${esc(s.location)}</div>
      <div class="foot-links">${links}</div>
      <div>${esc(s.footerNote)}</div>
    </div>
  </footer>`;
}

/**
 * Enveloppe le corps d'une page dans le gabarit complet.
 * @param {object} o - { content, base, title, description, path, body }
 */
export function page(o) {
  const { content, base, title, description, path, body } = o;
  const s = content.site;
  const fullTitle = path === '/' ? `${s.name} — ${s.tagline}` : `${title} · ${s.name}`;
  const desc = description || s.description;

  return `<!doctype html>
<html lang="fr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(fullTitle)}</title>
<meta name="description" content="${esc(desc)}">
<meta name="color-scheme" content="dark">
<meta name="theme-color" content="#08090C">
<meta property="og:type" content="website">
<meta property="og:title" content="${esc(fullTitle)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:site_name" content="${esc(s.name)}">
<meta name="twitter:card" content="summary_large_image">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='7' fill='%2308090C'/%3E%3Ccircle cx='16' cy='16' r='6' fill='%239FB4FF'/%3E%3C/svg%3E">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="${esc(FONTS)}">
<link rel="stylesheet" href="${esc(link(base, '/assets/main.css'))}">
</head>
<body>
<a class="skip" href="#main">Aller au contenu</a>
<div id="field" aria-hidden="true"></div>

<div class="shell">
  <header class="masthead">
    <div class="wrap masthead-inner">
      <a class="logo" href="${esc(link(base, '/'))}"><span class="mark"></span>${esc(s.name)}</a>
      <button class="burger" type="button" aria-expanded="false" aria-controls="nav" aria-label="Menu"><span></span></button>
      <nav class="nav" id="nav">${nav(content, base, path)}</nav>
    </div>
  </header>

  <main id="main">
${body}
  </main>

${footer(content, base)}
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js" defer></script>
<script src="${esc(link(base, '/assets/field.js'))}" defer></script>
<script src="${esc(link(base, '/assets/site.js'))}" defer></script>
</body>
</html>
`;
}
