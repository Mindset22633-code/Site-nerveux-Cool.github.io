/* Corps des quatre pages. Tout le texte vient de content.json. */
import { esc, link } from './layout.mjs';

const btn = (base, cta, variant) =>
  cta && cta.label
    ? `<a class="btn btn--${variant}" href="${esc(link(base, cta.href))}">${esc(cta.label)}</a>`
    : '';

const statusClass = (s = '') => {
  const t = s.toLowerCase();
  if (t.includes('ligne') || t.includes('live')) return 'status--live';
  if (t.includes('dévelop') || t.includes('develop') || t.includes('cours')) return 'status--wip';
  return 'status--proto';
};

/* ------------------------------------------------------------ Accueil */
export function home(content, base) {
  const h = content.home;
  return `
    <section class="wrap hero">
      <p class="eyebrow rise">${esc(h.hero.eyebrow)}</p>
      <h1 class="display rise d1">${esc(h.hero.title)} <em>${esc(h.hero.titleAccent)}</em></h1>
      <p class="lede rise d2">${esc(h.hero.subtitle)}</p>
      <div class="hero-actions rise d3">
        ${btn(base, h.hero.primaryCta, 'primary')}
        ${btn(base, h.hero.secondaryCta, 'ghost')}
      </div>
    </section>

    <section class="wrap section--tight">
      <div class="stats rise">
        ${h.stats
          .map((s) => `<div class="stat"><div class="v">${esc(s.value)}</div><div class="k">${esc(s.label)}</div></div>`)
          .join('')}
      </div>
    </section>

    <section class="wrap section">
      <div class="section-head">
        <div>
          <p class="eyebrow rise">Services</p>
          <h2 class="h2 rise d1">${esc(h.sectionsTitle)}</h2>
        </div>
        <p class="lede rise d2" style="max-width:38ch">${esc(h.sectionsIntro)}</p>
      </div>
      <div class="grid">
        ${h.services
          .map(
            (s, i) => `
        <article class="card rise d${(i % 3) + 1}">
          <div class="n">${String(i + 1).padStart(2, '0')}</div>
          <h3>${esc(s.title)}</h3>
          <p>${esc(s.description)}</p>
        </article>`
          )
          .join('')}
      </div>
    </section>

    <section class="wrap section">
      <div class="closing rise">
        <div class="txt">
          <h2 class="h2">${esc(h.closingTitle)}</h2>
          <p>${esc(h.closingText)}</p>
        </div>
        ${btn(base, h.closingCta, 'primary')}
      </div>
    </section>
  `;
}

/* ------------------------------------------------------------ Projets */
export function projects(content, base) {
  const p = content.projects;
  return `
    <section class="wrap page-head">
      <p class="eyebrow rise">Réalisations</p>
      <h1 class="display rise d1">${esc(p.title)}</h1>
      <p class="lede rise d2">${esc(p.intro)}</p>
    </section>

    <section class="wrap section--tight">
      <div class="projects">
        ${p.items
          .map((it) => {
            const tags = (it.tags || []).map((t) => `<span class="tag">${esc(t)}</span>`).join('');
            const inner = `
            <div class="yr">${esc(it.year)}</div>
            <div><h3>${esc(it.name)}</h3><div class="tags">${tags}</div></div>
            <div><p class="sum">${esc(it.summary)}</p></div>
            <div><span class="status ${statusClass(it.status)}">${esc(it.status)}</span></div>`;
            return it.href
              ? `<a class="project rise" href="${esc(it.href)}" rel="noopener">${inner}</a>`
              : `<article class="project rise">${inner}</article>`;
          })
          .join('')}
      </div>
    </section>

    <section class="wrap section">
      <div class="closing rise">
        <div class="txt">
          <h2 class="h2">${esc(content.home.closingTitle)}</h2>
          <p>${esc(content.home.closingText)}</p>
        </div>
        ${btn(base, content.home.closingCta, 'primary')}
      </div>
    </section>
  `;
}

/* ------------------------------------------------------------ Approche */
export function about(content, base) {
  const a = content.about;
  return `
    <section class="wrap page-head">
      <p class="eyebrow rise">À propos</p>
      <h1 class="display rise d1">${esc(a.title)}</h1>
      <p class="lede rise d2">${esc(a.lede)}</p>
    </section>

    <section class="wrap section--tight">
      <div class="split split--aside">
        <div class="prose rise">
          ${a.body.map((par) => `<p>${esc(par)}</p>`).join('')}
        </div>
        <div class="rise d2">
          <p class="label" style="margin:0 0 16px">${esc(a.stackTitle)}</p>
          <div class="chips">
            ${a.stack.map((s) => `<span class="chip">${esc(s)}</span>`).join('')}
          </div>
        </div>
      </div>
    </section>

    <section class="wrap section">
      <div class="section-head">
        <h2 class="h2 rise">${esc(a.principlesTitle)}</h2>
      </div>
      <div class="principles rise d1">
        ${a.principles
          .map((pr) => `<div class="principle"><h3>${esc(pr.title)}</h3><p>${esc(pr.text)}</p></div>`)
          .join('')}
      </div>
    </section>

    <section class="wrap section">
      <div class="closing rise">
        <div class="txt">
          <h2 class="h2">${esc(content.home.closingTitle)}</h2>
          <p>${esc(content.home.closingText)}</p>
        </div>
        ${btn(base, content.home.closingCta, 'primary')}
      </div>
    </section>
  `;
}

/* ------------------------------------------------------------ Contact */
export function contact(content) {
  const c = content.contact;
  const f = c.fields;
  const mail = content.site.email;
  return `
    <section class="wrap page-head">
      <p class="eyebrow rise">Écrire</p>
      <h1 class="display rise d1">${esc(c.title)}</h1>
      <p class="lede rise d2">${esc(c.lede)}</p>
    </section>

    <section class="wrap section--tight">
      <div class="split split--aside">
        <form class="form rise" id="contact-form" data-to="${esc(mail)}" novalidate>
          <div class="field">
            <label for="f-name">${esc(f.nameLabel)}</label>
            <input id="f-name" name="name" type="text" autocomplete="name" required>
          </div>
          <div class="field">
            <label for="f-email">${esc(f.emailLabel)}</label>
            <input id="f-email" name="email" type="email" autocomplete="email" required>
          </div>
          <div class="field">
            <label for="f-subject">${esc(f.subjectLabel)}</label>
            <input id="f-subject" name="subject" type="text">
          </div>
          <div class="field">
            <label for="f-message">${esc(f.messageLabel)}</label>
            <textarea id="f-message" name="message" required></textarea>
          </div>
          <div><button class="btn btn--primary" type="submit">${esc(f.submitLabel)}</button></div>
        </form>

        <aside class="aside-box rise d2">
          <h3>${esc(c.asideTitle)}</h3>
          <p>${esc(c.asideText)}</p>
          <p style="margin-bottom:10px" class="label">Email direct</p>
          <a class="mail" href="mailto:${esc(mail)}">${esc(mail)}</a>
          <p style="margin:22px 0 0;font-size:13.5px;color:var(--muted)">${esc(c.formIntro)}</p>
        </aside>
      </div>
    </section>
  `;
}

/* ------------------------------------------------------------ 404 */
export function notFound(content, base) {
  return `
    <section class="wrap hero">
      <p class="eyebrow rise">Erreur 404</p>
      <h1 class="display rise d1">Cette page <em>n'existe pas.</em></h1>
      <p class="lede rise d2">Le lien est peut-être ancien, ou l'adresse mal recopiée.</p>
      <div class="hero-actions rise d3">
        <a class="btn btn--primary" href="${esc(link(base, '/'))}">Retour à l'accueil</a>
      </div>
    </section>
  `;
}
