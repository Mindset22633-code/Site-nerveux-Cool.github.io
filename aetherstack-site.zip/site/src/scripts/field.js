/* ============================================================
   Champ 3D d'arrière-plan — "aether"
   Structure filaire + nuage de particules, réagit au scroll
   et à la souris. Se met en pause quand l'onglet est caché.
   ============================================================ */
(function () {
  'use strict';

  var host = document.getElementById('field');
  if (!host || typeof THREE === 'undefined') return;

  var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var small = window.innerWidth < 760;

  var renderer = new THREE.WebGLRenderer({ antialias: !small, alpha: true, powerPreference: 'low-power' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, small ? 1.5 : 2));
  renderer.setSize(window.innerWidth, window.innerHeight);
  host.appendChild(renderer.domElement);

  var scene = new THREE.Scene();
  var camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 120);
  camera.position.set(0, 0, 15);

  var ACCENT = new THREE.Color('#9FB4FF');
  var SIGNAL = new THREE.Color('#FFB86B');

  var group = new THREE.Group();
  scene.add(group);

  /* --- noyau filaire --- */
  var coreGeo = new THREE.IcosahedronGeometry(3.4, 3);
  var basePos = coreGeo.attributes.position.array.slice();
  var coreMat = new THREE.MeshBasicMaterial({
    color: ACCENT, wireframe: true, transparent: true, opacity: 0.17
  });
  var core = new THREE.Mesh(coreGeo, coreMat);
  group.add(core);

  /* --- coque externe, plus lente --- */
  var shellGeo = new THREE.IcosahedronGeometry(5.6, 1);
  var shellMat = new THREE.MeshBasicMaterial({
    color: ACCENT, wireframe: true, transparent: true, opacity: 0.07
  });
  var shell = new THREE.Mesh(shellGeo, shellMat);
  group.add(shell);

  /* --- particules --- */
  var COUNT = small ? 220 : 620;
  var pGeo = new THREE.BufferGeometry();
  var pPos = new Float32Array(COUNT * 3);
  var pCol = new Float32Array(COUNT * 3);
  var drift = new Float32Array(COUNT);
  var c = new THREE.Color();

  for (var i = 0; i < COUNT; i++) {
    var r = 6 + Math.random() * 14;
    var th = Math.random() * Math.PI * 2;
    var ph = Math.acos(2 * Math.random() - 1);
    pPos[i * 3]     = r * Math.sin(ph) * Math.cos(th);
    pPos[i * 3 + 1] = r * Math.sin(ph) * Math.sin(th) * 0.6;
    pPos[i * 3 + 2] = r * Math.cos(ph);
    drift[i] = 0.15 + Math.random() * 0.5;
    // 1 particule sur 14 prend la teinte chaude
    c.copy(i % 14 === 0 ? SIGNAL : ACCENT);
    c.multiplyScalar(0.55 + Math.random() * 0.45);
    pCol[i * 3] = c.r; pCol[i * 3 + 1] = c.g; pCol[i * 3 + 2] = c.b;
  }
  pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3));
  pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));

  var pMat = new THREE.PointsMaterial({
    size: 0.055, vertexColors: true, transparent: true,
    opacity: 0.75, sizeAttenuation: true, depthWrite: false
  });
  var points = new THREE.Points(pGeo, pMat);
  scene.add(points);

  /* --- entrées --- */
  var mx = 0, my = 0, tmx = 0, tmy = 0;
  var scrollY = 0, tScrollY = 0;

  if (!small) {
    window.addEventListener('pointermove', function (e) {
      tmx = (e.clientX / window.innerWidth - 0.5) * 2;
      tmy = (e.clientY / window.innerHeight - 0.5) * 2;
    }, { passive: true });
  }

  function onScroll() {
    var max = document.documentElement.scrollHeight - window.innerHeight;
    tScrollY = max > 0 ? window.scrollY / max : 0;
  }
  onScroll();
  window.addEventListener('scroll', onScroll, { passive: true });

  var resizeTimer;
  window.addEventListener('resize', function () {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function () {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      onScroll();
    }, 120);
  });

  /* --- boucle --- */
  var running = true;
  document.addEventListener('visibilitychange', function () {
    running = !document.hidden;
    if (running) { last = performance.now(); requestAnimationFrame(tick); }
  });

  var last = performance.now();
  var t = 0;
  var corePos = coreGeo.attributes.position;

  function tick(now) {
    if (!running) return;
    var dt = Math.min(0.05, (now - last) / 1000);
    last = now;
    t += dt;

    mx += (tmx - mx) * Math.min(1, dt * 2.2);
    my += (tmy - my) * Math.min(1, dt * 2.2);
    scrollY += (tScrollY - scrollY) * Math.min(1, dt * 3);

    if (!reduce) {
      // respiration du noyau
      for (var i = 0; i < corePos.count; i++) {
        var ix = i * 3;
        var bx = basePos[ix], by = basePos[ix + 1], bz = basePos[ix + 2];
        var n = Math.sin(bx * 0.85 + t * 0.75) * Math.cos(by * 0.85 - t * 0.55) * 0.16;
        var k = 1 + n;
        corePos.array[ix] = bx * k;
        corePos.array[ix + 1] = by * k;
        corePos.array[ix + 2] = bz * k;
      }
      corePos.needsUpdate = true;

      group.rotation.y = t * 0.055 + mx * 0.28 + scrollY * 1.5;
      group.rotation.x = Math.sin(t * 0.16) * 0.09 + my * 0.16;
      shell.rotation.y = -t * 0.035;
      shell.rotation.z = t * 0.02;

      points.rotation.y = -t * 0.018 + mx * 0.1;
      points.rotation.x = my * 0.06;

      // les particules dérivent doucement vers le haut puis reviennent
      var pa = pGeo.attributes.position.array;
      for (var j = 0; j < COUNT; j++) {
        pa[j * 3 + 1] += drift[j] * dt * 0.32;
        if (pa[j * 3 + 1] > 11) pa[j * 3 + 1] = -11;
      }
      pGeo.attributes.position.needsUpdate = true;
    }

    // la caméra recule légèrement au fil du scroll
    camera.position.z = 15 + scrollY * 5.5;
    camera.position.y = -scrollY * 1.8;
    camera.lookAt(0, 0, 0);

    // l'opacité du noyau monte un peu en bas de page
    coreMat.opacity = 0.17 + scrollY * 0.1;

    renderer.render(scene, camera);
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})();
