/* ============================================================
   Comportements du site : menu mobile, révélations au scroll,
   formulaire de contact (mailto, aucun service tiers).
   ============================================================ */
(function () {
  'use strict';

  /* --- menu mobile --- */
  var burger = document.querySelector('.burger');
  var nav = document.getElementById('nav');
  if (burger && nav) {
    var sync = function () {
      if (window.innerWidth > 720) { nav.hidden = false; burger.setAttribute('aria-expanded', 'false'); }
      else if (burger.getAttribute('aria-expanded') !== 'true') { nav.hidden = true; }
    };
    sync();
    window.addEventListener('resize', sync);
    burger.addEventListener('click', function () {
      var open = burger.getAttribute('aria-expanded') === 'true';
      burger.setAttribute('aria-expanded', String(!open));
      nav.hidden = open;
    });
    nav.addEventListener('click', function (e) {
      if (e.target.tagName === 'A' && window.innerWidth <= 720) {
        burger.setAttribute('aria-expanded', 'false');
        nav.hidden = true;
      }
    });
  }

  /* --- révélations au scroll --- */
  var targets = document.querySelectorAll('.rise');
  if (targets.length) {
    if (!('IntersectionObserver' in window)) {
      Array.prototype.forEach.call(targets, function (el) { el.classList.add('in'); });
    } else {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add('in'); io.unobserve(en.target); }
        });
      }, { threshold: 0.12, rootMargin: '0px 0px -6% 0px' });
      Array.prototype.forEach.call(targets, function (el) { io.observe(el); });
    }
  }

  /* --- formulaire de contact --- */
  var form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var to = form.getAttribute('data-to') || '';
      var name = (form.elements.name.value || '').trim();
      var mail = (form.elements.email.value || '').trim();
      var subj = (form.elements.subject.value || '').trim() || 'Prise de contact';
      var msg = (form.elements.message.value || '').trim();
      var body = msg + '\n\n—\n' + name + (mail ? '\n' + mail : '');
      window.location.href = 'mailto:' + encodeURIComponent(to) +
        '?subject=' + encodeURIComponent(subj) +
        '&body=' + encodeURIComponent(body);
    });
  }

  /* --- année courante dans le pied de page --- */
  var y = document.querySelectorAll('[data-year]');
  Array.prototype.forEach.call(y, function (el) { el.textContent = String(new Date().getFullYear()); });
})();
